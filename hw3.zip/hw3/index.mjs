// import express from 'express';
// const swapi = require('swapi-node');
// app.set("view engine", "ejs");
import express, { query } from 'express'; // 
import fetch from 'node-fetch';
const swapi = (await import('swapi-node')).default;
const app = express();
app.set("view engine", "ejs");
app.use(express.static("public"));

// https://swapi.dev/api/species/2 
// species api link

app.get('/', (req, res) => { // home page
//    res.send('Hello Express app!')
   res.render('home.ejs')
});


// app.get('/luke', async (req, res) => {
//     // let luke = swapi.people;
//     let url1 = "https://swapi.dev/api/people/1/";
//     let response = await fetch(url1);
//     let data1 = await response.json();
//     // console.log(data1);
//     let luke = data1;
//     // console.log(luke);
//     res.render('luke.ejs', {luke})
//     console.log(luke);
// });

app.get('/luke', async (req, res) => {
    // let luke = await swapi.people({id: 1});
    let person = await swapi.people({id: 1});

    const homeworldUrl = person.homeworld;
    const homeworldResponse = await fetch(homeworldUrl);
    const homeworldData = await homeworldResponse.json();

    let img1 = "https://starwars-visualguide.com/assets/img/characters/1.jpg"; 
    let img2 = "/img/tatooine.jpg";

    // changed 'luke' to 'person' for partials
    // alternatively can do 'person: luke' in render
    res.render('luke.ejs', {person, img1, img2, homeworldData});
    // console.log(homeworldData);
});

app.get('/vader', async (req, res) => {
    let person = await swapi.people({id: 4});

    const homeworldUrl = person.homeworld;
    const homeworldResponse = await fetch(homeworldUrl);
    const homeworldData = await homeworldResponse.json();

    let img1 = "https://starwars-visualguide.com/assets/img/characters/4.jpg";
    // let img2 = "https://starwars-visualguide.com/assets/img/planets/4.jpg";
    // above is not actual homeworld; id doesn't match in this case to planet
    let img2 = "/img/tatooine.jpg";

    res.render('vader.ejs', {person, img1,img2, homeworldData});
    // console.log(homeworldData);
});

app.get('/leia', async (req, res) => {
    let person = await swapi.people({id: 5});

    const homeworldUrl = person.homeworld;
    const homeworldResponse = await fetch(homeworldUrl);
    const homeworldData = await homeworldResponse.json();

    let img1 = "https://starwars-visualguide.com/assets/img/characters/5.jpg";
    let img2 = "https://starwars-visualguide.com/assets/img/planets/5.jpg";


    res.render('leia.ejs', {person, img1,img2, homeworldData});
    // console.log(homeworldData);
});

app.get('/r2d2', async (req, res) => {
    let person = await swapi.people({id: 3});

    const homeworldUrl = person.homeworld;
    const homeworldResponse = await fetch(homeworldUrl);
    const homeworldData = await homeworldResponse.json();

    let img1 = "https://starwars-visualguide.com/assets/img/characters/3.jpg";
    let img2 = "https://starwars-visualguide.com/assets/img/planets/3.jpg";

    res.render('r2d2.ejs', {person, img1,img2, homeworldData});
    // console.log(homeworldData);
});

app.get('/obiwan', async (req, res) => {
    let person = await swapi.people({id: 10});

    const homeworldUrl = person.homeworld;
    const homeworldResponse = await fetch(homeworldUrl);
    const homeworldData = await homeworldResponse.json();

    let img1 = "https://starwars-visualguide.com/assets/img/characters/10.jpg";
    let img2 = "https://starwars-visualguide.com/assets/img/planets/10.jpg";

    res.render('obiwan.ejs', {person, img1,img2, homeworldData});
    // console.log(homeworldData);
});

app.get('/species', async (req, res) => {
    const speciesId = req.query.speciesType;
    const speciesInfo = await swapi.species({id: speciesId});

    // let speciesType = await swapi.species({id: 1});
    // const homeworldUrl = `https://swapi.dev/api/species/${speciesId}/`;
    // const homeworldUrl = `https://swapi.dev/api/species/${speciesId}/`;

    const homeworldResponse = await fetch(speciesInfo.homeworld);
    const homeworldData = await homeworldResponse.json()
    
    let img1 = `https://starwars-visualguide.com/assets/img/species/${speciesId}.jpg`;
    let img2 = `https://starwars-visualguide.com/assets/img/planets/${speciesId}.jpg`;
    if(speciesId == 1) {
        img2="/img/coruscant.jpg";
    }
    res.render('species.ejs', {speciesId,speciesInfo,img1,img2,homeworldData});
    console.log(speciesId);
    console.log(speciesInfo);
    // console.log(homeworldData);
});


// swapi.people({ id: 1 }).then((result) => {
//     console.log(result);
// }); // gets Luke SkyWalker info

app.listen(10038, () => {
   console.log('server started');
});